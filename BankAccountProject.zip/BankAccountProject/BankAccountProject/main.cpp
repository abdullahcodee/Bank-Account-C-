#include "bankAccount.h"
#include <string>
using namespace std; 

int main()
{
    cout<<"WELCOME TO BEYKOZ BANK. "<< endl;
    cout<<"-------------------------------------------------"<< endl;
    cout<<"PLEASE FILL THE BELOW DATA TO CREATE ACCOUNT. "<< endl;
    cout<<"-------------------------------------------------"<< endl;
    
    string name;
    int acc_num;
    double acc_balance;
    
    cout<<"Please enter account name: "<<endl;
    cin>>name;
    cout<<"please enter account number: "<<endl;
    cin>>acc_num;
    cout<< "Please enter amount as a deposit in your account"<<endl;
    cin>>acc_balance;
    
    bankAccount *ACC1 = new bankAccount; 
    ACC1->setAccount(name,acc_num,acc_balance);
    cout<<"congratulations your account is created.\n\n"<<endl;
    
    
    
    int looper = 0;
    
    while (looper != -1)
    {
        int choise; 
        
        cout<<"please select the number of required transaction."<<endl;
        cout<<"to print your account information press (1)."<<endl;
        cout<<"to make a deposit press (2)."<<endl;
        cout<<"to make a withdraw press (3)."<<endl;
        cout<<"to check your balance press (4)."<<endl;
        cout<<"to check your current transactions (5)."<<endl;
        cout<<"delete account (6)."<<endl;


        cin>>choise;
        
        switch(choise)
        {
        
        case 1:
        if (choise == 1)
            {
                ACC1->print();
            }
            
        case 2:
        if (choise == 2)
            {
                double amount;
                cout<<"please enter amount to deposit in your account: "; 
                ACC1->deposit(amount);
            }
        case 3 : 
        if (choise == 3)
            {
                double amount;
                cout<<"please enter amount to withdraw in your account: "; 
                ACC1->withdraw(amount);
            }
            
        case 4 : 
        if (choise == 4)
            {
                cout<<"your balance is "<< ACC1->getBalance()<<endl;
            }
        case 5: 
        if (choise == 5)
            {
                ACC1->monthlyStatements();
            }
        
        case 6: 

        if (choise == 6)
            {
                cout<<"are you sure that you want to delete your account? (Y / N): "; 
                char confirm;
                cin>> confirm;
                if (confirm == 'Y' || confirm == 'y')
                {
                   delete ACC1;
                   cout<<"your account is deleted you can created another one."<<endl;
                }
                else 
                    continue;
            }
        }
        
        cout<<" TO EXIT PRESS -1 TO CONTINUE PRESS ANY OTHER NUMBER "<<endl;
        cin>>looper; 
    }

    cout<<"thanks for using our bank account application."<<endl; 
}